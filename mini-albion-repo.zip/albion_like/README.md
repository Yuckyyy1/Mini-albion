# Mini Albion

Прототип игры в стиле Albion Online на Python + Kivy: сбор ресурсов, вес, зелёная и красная зоны, рынок, прокачка.

## Запуск на ПК
    pip install kivy
    python main.py

## Сборка APK
APK собирается автоматически в GitHub Actions (вкладка Actions -> Build APK -> Artifacts -> mini-albion-apk).
Локально: `buildozer android debug` (Linux/WSL).
